<?php

// Setting specific configuration for the third part module:
$MCONF['phpMyAdminScript'] = '';	// or 'main.php','db_details.php', enter the script to load, if any
$MCONF['phpMyAdminSubDir'] = '';

if (!isset($MCONF['extModInclude'])) {
	$MCONF['extModInclude'] = 0;
}

// UN-COMMENT THIS LINE to activate phpMyAdmin! Please make sure the path is
// correct! (LOWERCASE!!) Enter the subdirectory of the scripts (LOWERCASE!!)
$MCONF['phpMyAdminSubDir'] = 'phpMyAdmin-2.6.4-pl3/';

$script_name = (php_sapi_name() == 'cgi'|| php_sapi_name() == 'cgi-fcgi') && (isset($_SERVER['ORIG_PATH_INFO']) ? $_SERVER['ORIG_PATH_INFO'] : $_SERVER['PATH_INFO']) ? (isset($_SERVER['ORIG_PATH_INFO']) ? $_SERVER['ORIG_PATH_INFO'] : $_SERVER['PATH_INFO']) : (isset($_SERVER['ORIG_SCRIPT_NAME']) ? $_SERVER['ORIG_SCRIPT_NAME'] : $_SERVER['SCRIPT_NAME']);

if (strstr($script_name, 'phpmyadmin.css.php'))	{
	$MCONF['phpMyAdminSubDir'] .= 'css/';
}

// Almost regular configuration of the module. Only if $MCONF['extModInclude'] 
// is set, then phpMyAdminSubDir is prepended to the TYPO3_MOD_PATH and '../' 
// to BACK_PATH. If this is not correct, init.php will exit!
$BACK_PATH='../../../' . ($MCONF['extModInclude'] ? '../' : '');

// Check if PMA is installed and executed in local context, if true modify paths
if (substr_count($_SERVER['SCRIPT_FILENAME'], 'typo3conf') > 0) {
	define('TYPO3_MOD_PATH', '../typo3conf/ext/phpmyadmin/modsub/' . ( $MCONF['extModInclude'] ? $MCONF['phpMyAdminSubDir'] : '' ));
	$BACK_PATH='../../../../' . ($MCONF['extModInclude'] ? '../' : '') . 'typo3/';
} else {
	define('TYPO3_MOD_PATH', 'ext/phpmyadmin/modsub/' . ($MCONF['extModInclude'] ? $MCONF['phpMyAdminSubDir'] : ''));
}

$MLANG['default']['tabs_images']['tab'] = 'thirdparty_db.gif';
$MLANG['default']['ll_ref'] = 'LLL:EXT:phpmyadmin/modsub/locallang_mod.php';

$MCONF['script'] = 'index.php';
$MCONF['access'] = 'admin';
$MCONF['name'] = 'tools_txphpmyadmin';

?>