<?php
/* $Id: info.inc.php,v 2.2.2.1 2005/09/05 11:42:12 lem9 Exp $ */
/* Theme information */
$theme_name = 'Darkblue/orange';
$theme_version = 1;
$theme_generation = 2;
?>
